tableextension 50109 "4HC Vendor" extends Vendor
{
    fields
    {
        field(50100; "REF SAP ID"; Code[20])
        {
            Caption = 'REF SAP ID';
            DataClassification = CustomerContent;
        }
        field(50101; "REF IFS ID"; Code[20])
        {
            Caption = 'REF IFS ID';
            DataClassification = CustomerContent;
        }
        field(50102; "Creation Date"; Date)
        {
            Caption = 'Creation Date';
            DataClassification = SystemMetadata;
        }
    }
    trigger OnInsert()
    begin
        "Creation Date":=Today();
    end;
}
