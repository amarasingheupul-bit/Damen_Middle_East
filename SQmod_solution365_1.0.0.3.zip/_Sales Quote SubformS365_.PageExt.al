pageextension 50122 "Sales Quote SubformS365" extends "Sales Quote Subform"
{
    layout
    {
        addafter(Quantity)
        {
            field("Package Type S365"; Rec."Package Type S365")
            {
                ApplicationArea = all;
                ToolTip = 'Specify sales qoute package type';
            }
            field(WidthS365; Rec.WidthS365)
            {
                ApplicationArea = all;
                ToolTip = 'Specify sales qoute package width';
            }
            field(HeightS365; Rec.HeightS365)
            {
                ApplicationArea = all;
                ToolTip = 'Specify sales qoute package height';
            }
            field(LengthS365; Rec.LengthS365)
            {
                ApplicationArea = all;
                ToolTip = 'Specify sales qoute package length';
            }
            field("Package Net Weight S365"; Rec."Net Weight")
            {
                ApplicationArea = all;
                ToolTip = 'Specify sales qoute package net weight';
            }
            field("No. of Packages S365"; Rec."No. of Packages S365")
            {
                ApplicationArea = All;
                ToolTip = 'Enter the total number of individual packages included in the shipment.';
            }
            field("No. of Pallets S365"; Rec."No. of Pallets S365")
            {
                ApplicationArea = All;
                ToolTip = 'Specify the total number of pallets used to organize the packages.';
            }
            field("Volume S365"; Rec."Volume S365")
            {
                ApplicationArea = All;
                ToolTip = 'Enter the total volume of the shipment, typically measured in cubic units.';
            }
            field("Volume Weight S365"; Rec."Volume Weight S365")
            {
                ApplicationArea = All;
                ToolTip = 'Specify the volume-based weight of the shipment, often used for freight calculations.';
            }
            field("Total Weight S365"; Rec."Total Weight S365")
            {
                ApplicationArea = All;
                ToolTip = 'Enter the combined weight of all items in the shipment, including packaging.';
            }
            field("HS Code S365"; Rec."HS Code S365")
            {
                ApplicationArea = All;
                ToolTip = 'Provide the Harmonized System (HS) code for classifying goods in the shipment.';
            }
        }
        modify("Qty. to Assemble to Order")
        {
            Visible = false;
        }
    }
    actions
    {
        addlast(processing)
        {
            action("Add Charge ItemsS365")
            {
                Caption = 'Add Charge Items';
                ApplicationArea = All;
                ToolTip = 'Add Charge items for selected service item';

                trigger OnAction()
                var
                    SQmodFunction: Codeunit "SQmodFunction S365";
                begin
                    SQmodFunction.AddChargeItem(Rec);
                end;
            }
        }
    }
}
