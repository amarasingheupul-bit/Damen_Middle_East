tableextension 50110 "4HC Purchase Header" extends "Purchase Header"
{
    fields
    {
        field(50100; "Commission Amount"; Decimal)
        {
            Caption = 'Commission Amount';
            DataClassification = CustomerContent;
        }
        field(50101; "OPCO Com Project No."; Code[50])
        {
            Caption = 'OPCO Com Project No.';
            DataClassification = CustomerContent;
        }
        field(50102; "SPA Date"; Date)
        {
            Caption = 'SPA Date';
            DataClassification = CustomerContent;
        }
        field(50103; "Amendment Date"; Date)
        {
            Caption = 'Amendment Date';
            DataClassification = CustomerContent;
        }
        field(50125; "Yard No."; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(50126; "Milestones Dates and Amounts"; Text[100])
        {
            DataClassification = ToBeClassified;
            Caption = 'Milestones with Dates and Amounts';
        }
        field(50128; "Group Customer with One Stream"; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Group Customer with One Stream Code';
            TableRelation = Customer;

            trigger OnValidate()
            var
                Customer: Record Customer;
            begin
                if Customer.Get("Group Customer with One Stream")then "Group Customr Name":=Customer.Name;
            end;
        }
        field(50104; "Group Customr Name"; Text[100])
        {
            DataClassification = ToBeClassified;
            Caption = 'Group Customr Name';
        }
    }
}
