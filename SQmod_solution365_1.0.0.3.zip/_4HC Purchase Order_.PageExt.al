pageextension 50115 "4HC Purchase Order" extends "Purchase Order"
{
    layout
    {
        addafter(General)
        {
            group(VendDetails)
            {
                ShowCaption = true;
                Caption = 'Additional Order Details';

                field("Commission Amount"; Rec."Commission Amount")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the commission value for this purchase order.';
                }
                field("OPCO Com Project No."; Rec."OPCO Com Project No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Indicates the OPCO commercial project number associated with the order.';
                }
                field("SPA Date"; Rec."SPA Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Defines the date of the signed purchase agreement.';
                }
                field("Amendment Date"; Rec."Amendment Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Shows the date of the last amendment to this purchase.';
                }
                field("Yard No."; Rec."Yard No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the yard reference for this order.';
                }
                field("Milestones Dates and Amounts"; Rec."Milestones Dates and Amounts")
                {
                    ApplicationArea = All;
                    ToolTip = 'Details key milestones, dates, and financial amounts linked to this purchase.';
                }
                field("Group Customer with One Stream"; Rec."Group Customer with One Stream")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the customer code from One Stream associated with this purchase.';
                }
                field("Group Customr Name"; Rec."Group Customr Name")
                {
                    ApplicationArea = All;
                    ToolTip = 'Automatically shows the customer name retrieved from One Stream on validation.';
                }
            }
        }
    }
}
